#!/usr/bin/env python
import scapy
from scapy.all import *

# StegoSender.py  script will:
#a) Prompt the user to enter the IP address of the other communicating party (i.e., of the machine currently running your StegoReceiver.py);
#b) Prompt the user to enter a simple (secret) sentence; 
#c) Break the sentence from b) into characters/letters; 
#d) Convert each character from c) into an integer value (e.g., using ascii code);
#e) Convert each sentence from d) into the Total Lengthfield/value of a new IP packet) into the Total Lengthfield/value of a new IP packet;
#f) Expend the size of the packet from d) into the Total Lengthfield/value of a new IP packet;f) Expend the size of the packet from 
#e) so as to match its specified Total Length; 
#f) Send each packet from e) to the destination IP indicated in a).

while True:
	try:
		receiverIP = input("Please enter the IP address of the Reciever: ") # or raw_input("Please enter the IP address of the Reciever: ")
		msg = input("Please enter the secret message you would like devlivered: ") # or raw_input("Please enter the secret message you would like devlivered: ")
	#	print(type(receiverIP))
		tlValues = [] #array for converted ascii values that will be used as Total Length for IP packets
		letters = list(msg)
		#print(letters)
		for c in letters:
			tlValues.append(ord(c))
	#	print(tlValues)
		
		packets = []
		for val in tlValues:
			#print(val)
			#pkt=IP (ihl=20, len=(val-20), ttl=225, dst=receiverIP)
			packets.append(IP(ihl=20, len=(val-20), ttl=225, dst=receiverIP))
	#	print(packets)
		for ip in packets:
				send(ip)
		break
	except (RuntimeError, NameError) :
		print("Oh something went wrong there. Please try with valid Reciever IP...")

	
				
