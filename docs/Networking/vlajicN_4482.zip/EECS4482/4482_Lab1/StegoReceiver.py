3 
#!/usr/bin/env python
import scapy
from scapy.all import *

#StegoReceiver.py  script will:
#a) Prompt the user to enter the IP address of the other communicating party (i.e., of the machine currently running your StegoSender.py);
#b) Listen for all IP packets arriving from the IP address indicated in a); 
#c) from each packet extract TL value and convert it to corresponding char.
#d) Combine all the extracted characters from c) into a sentence;
#e) Display the sentence from d) to the end-user.

#def pkt_callback(pkt), characters:
 #   pkt[IP].len # debug statement
while True:
		try:
			senderIp=input("Please enter IP of Sender: ") # or raw_input("Please enter IP of Sender: ")
			pkts=sniff(filter="ip and host " + senderIp, count=32)  #keep count to 32 IP packets i.e. characters 
											                  #for Graceful termination:)
			chars = []
			for pk in pkts:
				chars.append(chr(pk.len)) # dont have to use pkt[IP].len bc of filter!
			result = " "
			for x in chars:
					result += x
			print(result)
			break
		except(RuntimeError, SyntaxError, NameError):
				print("Oh something went wrong. Please enter valid Sender IP")




